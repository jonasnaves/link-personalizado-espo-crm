<?php
return array(
    'clientFiles' => array(
        'client/meu-link-personalizado.js'
    )
);
