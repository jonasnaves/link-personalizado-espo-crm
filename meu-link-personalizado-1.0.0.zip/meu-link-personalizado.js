define('client/meu-link-personalizado', ['app'], function (app) {
  'use strict';

  return {
    onMenuInit: function (menuItems) {
      // Este método é executado sempre que o menu é inicializado
    }
  };
});
